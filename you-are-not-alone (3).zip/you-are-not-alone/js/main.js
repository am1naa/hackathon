function ChangeToggler() {
    let element = document.getElementById("navbarTogglerIcon");
    element.classList.toggle("navbar-toggler-icon");
    element.classList.toggle("navbar-toggler-icon-x");
}